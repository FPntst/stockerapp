# StockFlow (.NET MAUI + C#)

App Android de estoque + To-Do, com o visual azul e roxo dos mockups.

## Telas
1. **Splash** – logo + barra de carregamento
2. **Login** – e-mail/senha (conta local, senha com hash PBKDF2) e **Criar conta**
3. **Início** – saudação, cards (Total / Em estoque / Baixos), busca e lista de produtos
4. **Produtos** – lista completa com busca e filtro por categoria
5. **Detalhes do produto** – quantidade, preço, categoria, descrição, Editar / Excluir
6. **Cadastrar / Editar produto** – ID automático para cada produto (`ID: 001`, `002`…)
7. **Tarefas (To-Do)** – filtros Todas / Pendentes / Concluídas, marcar como feita, menu ⋮
8. **Nova / Editar tarefa** – título, descrição, prioridade, data de vencimento
9. **Mais** – dados da conta e sair
O botão **+** central da barra inferior abre "Novo produto / Nova tarefa".

## Regras
- Estoque baixo = menos de 3 unidades (constante `Produto.LimiteBaixo`)
- Dados salvos localmente em SQLite (`stockflow.db3`)

## Desempenho
- Listas virtualizadas (`CollectionView`) com `ItemSizingStrategy="MeasureFirstItem"`
- Bindings compilados (`x:DataType`) + MVVM (CommunityToolkit.Mvvm)
- SQLite assíncrono; páginas principais mantidas em memória
- Release com AOT + Profiled AOT

## Rodar no Android
Requisitos: .NET 8 SDK, `dotnet workload install maui-android`, Android SDK, celular com Depuração USB.

```bash
dotnet build -t:Run -f net8.0-android
```

APK de teste: `dotnet build -f net8.0-android -c Debug` (arquivo `*-Signed.apk` em `bin/Debug/net8.0-android/`).
