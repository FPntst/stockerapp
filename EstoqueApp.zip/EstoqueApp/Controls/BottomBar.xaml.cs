namespace EstoqueApp.Controls;

public partial class BottomBar : ContentView
{
    private static readonly Color Ativa = Color.FromArgb("#22D3EE");
    private static readonly Color Inativa = Color.FromArgb("#8E9BD8");

    public static readonly BindableProperty AtivoProperty =
        BindableProperty.Create(nameof(Ativo), typeof(string), typeof(BottomBar), "inicio",
            propertyChanged: (b, _, _) => ((BottomBar)b).Atualizar());

    // "inicio", "produtos", "tarefas" ou "mais"
    public string Ativo
    {
        get => (string)GetValue(AtivoProperty);
        set => SetValue(AtivoProperty, value);
    }

    public BottomBar()
    {
        InitializeComponent();
        Atualizar();
    }

    private void Atualizar()
    {
        Marcar(icoInicio, txtInicio, Ativo == "inicio");
        Marcar(icoProdutos, txtProdutos, Ativo == "produtos");
        Marcar(icoTarefas, txtTarefas, Ativo == "tarefas");
        Marcar(icoMais, txtMais, Ativo == "mais");
    }

    private static void Marcar(Label icone, Label texto, bool ativo)
    {
        icone.Opacity = ativo ? 1 : 0.55;
        texto.TextColor = ativo ? Ativa : Inativa;
    }

    private async void OnInicio(object? sender, TappedEventArgs e) => await Shell.Current.GoToAsync("//inicio");
    private async void OnProdutos(object? sender, TappedEventArgs e) => await Shell.Current.GoToAsync("//produtos");
    private async void OnTarefas(object? sender, TappedEventArgs e) => await Shell.Current.GoToAsync("//tarefas");
    private async void OnMais(object? sender, TappedEventArgs e) => await Shell.Current.GoToAsync("//mais");

    private async void OnAdicionar(object? sender, TappedEventArgs e)
    {
        var acao = await Shell.Current.DisplayActionSheet("Adicionar", "Cancelar", null, "Novo produto", "Nova tarefa");
        if (acao == "Novo produto") await Shell.Current.GoToAsync("produto-form");
        else if (acao == "Nova tarefa") await Shell.Current.GoToAsync("tarefa-form");
    }
}
