using EstoqueApp.Services;
using EstoqueApp.ViewModels;
using EstoqueApp.Views;
using Microsoft.Extensions.Logging;
using Microsoft.Maui.Handlers;

namespace EstoqueApp;

public static class MauiProgram
{
    public static MauiApp CreateMauiApp()
    {
        var builder = MauiApp.CreateBuilder();
        builder.UseMauiApp<App>();

        RemoverSublinhadoAndroid();

        // Serviços
        builder.Services.AddSingleton<DatabaseService>();
        builder.Services.AddSingleton<AuthService>();

        // Telas principais (mantidas em memória para navegar mais rápido)
        builder.Services.AddSingleton<SplashPage>();
        builder.Services.AddSingleton<LoginPage>();
        builder.Services.AddSingleton<LoginViewModel>();
        builder.Services.AddSingleton<InicioPage>();
        builder.Services.AddSingleton<InicioViewModel>();
        builder.Services.AddSingleton<ProdutosPage>();
        builder.Services.AddSingleton<ProdutosViewModel>();
        builder.Services.AddSingleton<TarefasPage>();
        builder.Services.AddSingleton<TarefasViewModel>();
        builder.Services.AddSingleton<MaisPage>();
        builder.Services.AddSingleton<MaisViewModel>();

        // Telas empilhadas (novas a cada abertura)
        builder.Services.AddTransient<CadastroPage>();
        builder.Services.AddTransient<CadastroViewModel>();
        builder.Services.AddTransient<ProdutoDetalhePage>();
        builder.Services.AddTransient<ProdutoDetalheViewModel>();
        builder.Services.AddTransient<ProdutoFormPage>();
        builder.Services.AddTransient<ProdutoFormViewModel>();
        builder.Services.AddTransient<TarefaFormPage>();
        builder.Services.AddTransient<TarefaFormViewModel>();

#if DEBUG
        builder.Logging.AddDebug();
#endif
        return builder.Build();
    }

    // Tira a linha/fundo padrão dos campos no Android para combinar com o visual dos cartões
    private static void RemoverSublinhadoAndroid()
    {
#if ANDROID
        EntryHandler.Mapper.AppendToMapping("SemFundo",
            (h, v) => h.PlatformView.SetBackgroundColor(Android.Graphics.Color.Transparent));
        EditorHandler.Mapper.AppendToMapping("SemFundo",
            (h, v) => h.PlatformView.SetBackgroundColor(Android.Graphics.Color.Transparent));
        PickerHandler.Mapper.AppendToMapping("SemFundo",
            (h, v) => h.PlatformView.SetBackgroundColor(Android.Graphics.Color.Transparent));
        DatePickerHandler.Mapper.AppendToMapping("SemFundo",
            (h, v) => h.PlatformView.SetBackgroundColor(Android.Graphics.Color.Transparent));
#endif
    }
}
