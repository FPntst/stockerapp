using EstoqueApp.ViewModels;

namespace EstoqueApp.Views;

public partial class ProdutoFormPage : ContentPage
{
    private readonly ProdutoFormViewModel _vm;

    public ProdutoFormPage(ProdutoFormViewModel vm)
    {
        InitializeComponent();
        BindingContext = _vm = vm;
    }

    protected override async void OnAppearing()
    {
        base.OnAppearing();
        await _vm.CarregarAsync();
    }
}
