using EstoqueApp.ViewModels;

namespace EstoqueApp.Views;

public partial class TarefasPage : ContentPage
{
    private readonly TarefasViewModel _vm;

    public TarefasPage(TarefasViewModel vm)
    {
        InitializeComponent();
        BindingContext = _vm = vm;
    }

    protected override async void OnAppearing()
    {
        base.OnAppearing();
        await _vm.CarregarAsync();
    }
}
