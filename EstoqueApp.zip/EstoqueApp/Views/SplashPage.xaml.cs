using EstoqueApp.Services;

namespace EstoqueApp.Views;

public partial class SplashPage : ContentPage
{
    private readonly AuthService _auth;
    private bool _iniciado;

    public SplashPage(AuthService auth)
    {
        InitializeComponent();
        _auth = auth;
    }

    protected override async void OnAppearing()
    {
        base.OnAppearing();
        if (_iniciado) return;
        _iniciado = true;

        var sessao = _auth.RestaurarSessaoAsync();
        await barra.ProgressTo(1, 1300, Easing.CubicInOut);
        var logado = await sessao;

        await Shell.Current.GoToAsync(logado ? "//inicio" : "//login");
    }
}
