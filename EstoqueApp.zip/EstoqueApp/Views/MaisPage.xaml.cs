using EstoqueApp.ViewModels;

namespace EstoqueApp.Views;

public partial class MaisPage : ContentPage
{
    private readonly MaisViewModel _vm;

    public MaisPage(MaisViewModel vm)
    {
        InitializeComponent();
        BindingContext = _vm = vm;
    }

    protected override void OnAppearing()
    {
        base.OnAppearing();
        _vm.Carregar();
    }
}
