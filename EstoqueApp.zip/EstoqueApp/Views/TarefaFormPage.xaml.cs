using EstoqueApp.ViewModels;

namespace EstoqueApp.Views;

public partial class TarefaFormPage : ContentPage
{
    private readonly TarefaFormViewModel _vm;

    public TarefaFormPage(TarefaFormViewModel vm)
    {
        InitializeComponent();
        BindingContext = _vm = vm;
    }

    protected override async void OnAppearing()
    {
        base.OnAppearing();
        await _vm.CarregarAsync();
    }
}
