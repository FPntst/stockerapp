using EstoqueApp.ViewModels;

namespace EstoqueApp.Views;

public partial class CadastroPage : ContentPage
{
    public CadastroPage(CadastroViewModel vm)
    {
        InitializeComponent();
        BindingContext = vm;
    }
}
