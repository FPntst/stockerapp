using EstoqueApp.ViewModels;

namespace EstoqueApp.Views;

public partial class ProdutoDetalhePage : ContentPage
{
    private readonly ProdutoDetalheViewModel _vm;

    public ProdutoDetalhePage(ProdutoDetalheViewModel vm)
    {
        InitializeComponent();
        BindingContext = _vm = vm;
    }

    protected override async void OnAppearing()
    {
        base.OnAppearing();
        await _vm.CarregarAsync();
    }
}
