using EstoqueApp.Views;

namespace EstoqueApp;

public partial class AppShell : Shell
{
    public AppShell()
    {
        InitializeComponent();

        // Telas empilhadas (abrem por cima das principais)
        Routing.RegisterRoute("cadastro", typeof(CadastroPage));
        Routing.RegisterRoute("produto-detalhe", typeof(ProdutoDetalhePage));
        Routing.RegisterRoute("produto-form", typeof(ProdutoFormPage));
        Routing.RegisterRoute("tarefa-form", typeof(TarefaFormPage));
    }
}
