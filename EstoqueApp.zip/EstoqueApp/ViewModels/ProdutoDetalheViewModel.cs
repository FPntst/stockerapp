using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using EstoqueApp.Models;
using EstoqueApp.Services;

namespace EstoqueApp.ViewModels;

[QueryProperty(nameof(IdParametro), "id")]
public partial class ProdutoDetalheViewModel : ObservableObject
{
    private readonly DatabaseService _db;
    private int _id;

    [ObservableProperty] private Produto? produto;

    public string IdParametro
    {
        set => int.TryParse(value, out _id);
    }

    public ProdutoDetalheViewModel(DatabaseService db) => _db = db;

    public async Task CarregarAsync() => Produto = await _db.ObterProdutoAsync(_id);

    [RelayCommand]
    private async Task VoltarAsync() => await Shell.Current.GoToAsync("..");

    [RelayCommand]
    private async Task EditarAsync() => await Shell.Current.GoToAsync($"produto-form?id={_id}");

    [RelayCommand]
    private async Task ExcluirAsync()
    {
        if (Produto is null) return;
        var ok = await Shell.Current.DisplayAlert("Excluir produto",
            $"Deseja excluir \"{Produto.Nome}\" ({Produto.IdTexto})?", "Excluir", "Cancelar");
        if (!ok) return;

        await _db.ApagarProdutoAsync(Produto);
        await Shell.Current.GoToAsync("..");
    }
}
