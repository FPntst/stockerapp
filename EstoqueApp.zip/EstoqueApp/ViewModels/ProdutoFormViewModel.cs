using System.Globalization;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using EstoqueApp.Models;
using EstoqueApp.Services;

namespace EstoqueApp.ViewModels;

[QueryProperty(nameof(IdParametro), "id")]
public partial class ProdutoFormViewModel : ObservableObject
{
    private static readonly CultureInfo Br = new("pt-BR");
    private readonly DatabaseService _db;
    private Produto _produto = new();
    private int _id;
    private bool _carregado;

    public IReadOnlyList<string> Categorias => Produto.CategoriasPadrao;

    [ObservableProperty] private string titulo = "Cadastrar Produto";
    [ObservableProperty] private string textoBotao = "Salvar";
    [ObservableProperty] private bool modoEdicao;
    [ObservableProperty] private Produto? resumo;

    [ObservableProperty] private string nome = string.Empty;
    [ObservableProperty] private string? categoria;
    [ObservableProperty] private string quantidade = string.Empty;
    [ObservableProperty] private string preco = string.Empty;
    [ObservableProperty] private string descricao = string.Empty;

    public string IdParametro
    {
        set => int.TryParse(value, out _id);
    }

    public ProdutoFormViewModel(DatabaseService db) => _db = db;

    public async Task CarregarAsync()
    {
        if (_carregado) return;
        _carregado = true;
        if (_id == 0) return;

        var p = await _db.ObterProdutoAsync(_id);
        if (p is null) return;

        _produto = p;
        Resumo = p;
        ModoEdicao = true;
        Titulo = "Editar Produto";
        TextoBotao = "Salvar Alterações";
        Nome = p.Nome;
        Categoria = p.Categoria;
        Quantidade = p.Quantidade.ToString();
        Preco = p.Preco.ToString("F2", Br);
        Descricao = p.Descricao;
    }

    private static bool TentarPreco(string texto, out double valor)
    {
        texto = texto.Replace("R$", "").Trim();
        if (texto.Contains(',')) texto = texto.Replace(".", "").Replace(',', '.');
        return double.TryParse(texto, NumberStyles.Float, CultureInfo.InvariantCulture, out valor) && valor >= 0;
    }

    [RelayCommand]
    private async Task SalvarAsync()
    {
        if (string.IsNullOrWhiteSpace(Nome))
        {
            await Shell.Current.DisplayAlert("Atenção", "Informe o nome do produto.", "OK");
            return;
        }
        if (string.IsNullOrEmpty(Categoria))
        {
            await Shell.Current.DisplayAlert("Atenção", "Selecione uma categoria.", "OK");
            return;
        }

        var qtd = 0;
        if (!string.IsNullOrWhiteSpace(Quantidade) && (!int.TryParse(Quantidade, out qtd) || qtd < 0))
        {
            await Shell.Current.DisplayAlert("Atenção", "Quantidade inválida.", "OK");
            return;
        }

        var valor = 0d;
        if (!string.IsNullOrWhiteSpace(Preco) && !TentarPreco(Preco, out valor))
        {
            await Shell.Current.DisplayAlert("Atenção", "Preço inválido.", "OK");
            return;
        }

        _produto.Nome = Nome.Trim();
        _produto.Categoria = Categoria;
        _produto.Quantidade = qtd;
        _produto.Preco = valor;
        _produto.Descricao = Descricao.Trim();

        await _db.SalvarProdutoAsync(_produto);
        await Shell.Current.GoToAsync("..");
    }

    [RelayCommand]
    private async Task VoltarAsync() => await Shell.Current.GoToAsync("..");
}
