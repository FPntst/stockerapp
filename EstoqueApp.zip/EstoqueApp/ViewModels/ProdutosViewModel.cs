using System.Collections.ObjectModel;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using EstoqueApp.Models;
using EstoqueApp.Services;

namespace EstoqueApp.ViewModels;

public partial class ProdutosViewModel : ObservableObject
{
    private readonly DatabaseService _db;
    private List<Produto> _todos = new();
    private string? _categoria; // null = Todos

    public ObservableCollection<Produto> Produtos { get; } = new();
    public ObservableCollection<Chip> Categorias { get; } = new();

    [ObservableProperty] private string busca = string.Empty;
    [ObservableProperty] private Produto? selecionado;

    public ProdutosViewModel(DatabaseService db)
    {
        _db = db;
        Categorias.Add(new Chip { Texto = "Todos", Selecionado = true });
        foreach (var c in Produto.CategoriasPadrao)
            Categorias.Add(new Chip { Texto = c });
    }

    partial void OnBuscaChanged(string value) => Filtrar();

    partial void OnSelecionadoChanged(Produto? value)
    {
        if (value is null) return;
        var id = value.Id;
        Selecionado = null;
        _ = Shell.Current.GoToAsync($"produto-detalhe?id={id}");
    }

    public async Task CarregarAsync()
    {
        _todos = await _db.ListarProdutosAsync();
        Filtrar();
    }

    private void Filtrar()
    {
        var termo = Busca?.Trim() ?? string.Empty;
        IEnumerable<Produto> lista = _todos;

        if (_categoria is not null)
            lista = lista.Where(p => p.Categoria == _categoria);

        if (termo.Length > 0)
            lista = lista.Where(p => p.Nome.Contains(termo, StringComparison.OrdinalIgnoreCase)
                                  || p.IdTexto.Contains(termo, StringComparison.OrdinalIgnoreCase));

        Produtos.Clear();
        foreach (var p in lista) Produtos.Add(p);
    }

    [RelayCommand]
    private void SelecionarCategoria(Chip chip)
    {
        foreach (var c in Categorias) c.Selecionado = c == chip;
        _categoria = chip.Texto == "Todos" ? null : chip.Texto;
        Filtrar();
    }

    [RelayCommand]
    private async Task NovoAsync() => await Shell.Current.GoToAsync("produto-form");
}
