using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using EstoqueApp.Services;

namespace EstoqueApp.ViewModels;

public partial class LoginViewModel : ObservableObject
{
    private readonly AuthService _auth;

    [ObservableProperty] private string email = string.Empty;
    [ObservableProperty] private string senha = string.Empty;
    [ObservableProperty] private bool senhaOculta = true;
    [ObservableProperty] private bool ocupado;

    public LoginViewModel(AuthService auth) => _auth = auth;

    [RelayCommand]
    private void AlternarSenha() => SenhaOculta = !SenhaOculta;

    [RelayCommand]
    private async Task EntrarAsync()
    {
        if (string.IsNullOrWhiteSpace(Email) || string.IsNullOrWhiteSpace(Senha))
        {
            await Shell.Current.DisplayAlert("Atenção", "Informe e-mail e senha.", "OK");
            return;
        }

        Ocupado = true;
        var ok = await _auth.EntrarAsync(Email, Senha);
        Ocupado = false;

        if (!ok)
        {
            await Shell.Current.DisplayAlert("Não foi possível entrar", "E-mail ou senha incorretos.", "OK");
            return;
        }

        Senha = string.Empty;
        await Shell.Current.GoToAsync("//inicio");
    }

    [RelayCommand]
    private async Task CriarContaAsync() => await Shell.Current.GoToAsync("cadastro");
}
