using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using EstoqueApp.Services;

namespace EstoqueApp.ViewModels;

public partial class MaisViewModel : ObservableObject
{
    private readonly AuthService _auth;

    [ObservableProperty] private string nome = string.Empty;
    [ObservableProperty] private string email = string.Empty;

    public MaisViewModel(AuthService auth) => _auth = auth;

    public void Carregar()
    {
        Nome = _auth.Atual?.Nome ?? string.Empty;
        Email = _auth.Atual?.Email ?? string.Empty;
    }

    [RelayCommand]
    private async Task SairAsync()
    {
        var ok = await Shell.Current.DisplayAlert("Sair", "Deseja sair da sua conta?", "Sair", "Cancelar");
        if (!ok) return;
        _auth.Sair();
        await Shell.Current.GoToAsync("//login");
    }
}
