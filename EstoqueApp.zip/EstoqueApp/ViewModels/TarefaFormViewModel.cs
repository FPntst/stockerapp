using System.Collections.ObjectModel;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using EstoqueApp.Models;
using EstoqueApp.Services;

namespace EstoqueApp.ViewModels;

[QueryProperty(nameof(IdParametro), "id")]
public partial class TarefaFormViewModel : ObservableObject
{
    private readonly DatabaseService _db;
    private Tarefa _tarefa = new();
    private int _id;
    private bool _carregado;

    public ObservableCollection<Chip> Prioridades { get; } = new();

    [ObservableProperty] private string titulo = "Nova Tarefa";
    [ObservableProperty] private string textoBotao = "Salvar";
    [ObservableProperty] private bool modoEdicao;

    [ObservableProperty] private string tituloTarefa = string.Empty;
    [ObservableProperty] private string descricao = string.Empty;
    [ObservableProperty] private DateTime vencimento = DateTime.Today;

    public string IdParametro
    {
        set => int.TryParse(value, out _id);
    }

    public TarefaFormViewModel(DatabaseService db)
    {
        _db = db;
        Prioridades.Add(new Chip { Texto = "Baixa", Valor = 0, Cor = Color.FromArgb("#3B82F6") });
        Prioridades.Add(new Chip { Texto = "Média", Valor = 1, Cor = Color.FromArgb("#F59E0B"), Selecionado = true });
        Prioridades.Add(new Chip { Texto = "Alta", Valor = 2, Cor = Color.FromArgb("#F43F5E") });
    }

    public async Task CarregarAsync()
    {
        if (_carregado) return;
        _carregado = true;
        if (_id == 0) return;

        var t = await _db.ObterTarefaAsync(_id);
        if (t is null) return;

        _tarefa = t;
        ModoEdicao = true;
        Titulo = "Editar Tarefa";
        TextoBotao = "Salvar Alterações";
        TituloTarefa = t.Titulo;
        Descricao = t.Descricao;
        Vencimento = t.Vencimento;
        foreach (var p in Prioridades) p.Selecionado = p.Valor == t.Prioridade;
    }

    [RelayCommand]
    private void SelecionarPrioridade(Chip chip)
    {
        foreach (var p in Prioridades) p.Selecionado = p == chip;
    }

    [RelayCommand]
    private async Task SalvarAsync()
    {
        if (string.IsNullOrWhiteSpace(TituloTarefa))
        {
            await Shell.Current.DisplayAlert("Atenção", "Informe o título da tarefa.", "OK");
            return;
        }

        _tarefa.Titulo = TituloTarefa.Trim();
        _tarefa.Descricao = Descricao.Trim();
        _tarefa.Vencimento = Vencimento.Date;
        _tarefa.Prioridade = Prioridades.FirstOrDefault(p => p.Selecionado)?.Valor ?? 1;

        await _db.SalvarTarefaAsync(_tarefa);
        await Shell.Current.GoToAsync("..");
    }

    [RelayCommand]
    private async Task ExcluirAsync()
    {
        if (!ModoEdicao) return;
        var ok = await Shell.Current.DisplayAlert("Excluir tarefa", $"Excluir \"{_tarefa.Titulo}\"?", "Excluir", "Cancelar");
        if (!ok) return;

        await _db.ApagarTarefaAsync(_tarefa);
        await Shell.Current.GoToAsync("..");
    }

    [RelayCommand]
    private async Task VoltarAsync() => await Shell.Current.GoToAsync("..");
}
