using System.Collections.ObjectModel;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using EstoqueApp.Models;
using EstoqueApp.Services;

namespace EstoqueApp.ViewModels;

public partial class TarefasViewModel : ObservableObject
{
    private readonly DatabaseService _db;
    private List<Tarefa> _todas = new();
    private int _filtro; // 0 = todas, 1 = pendentes, 2 = concluídas

    public ObservableCollection<Tarefa> Tarefas { get; } = new();
    public ObservableCollection<Chip> Filtros { get; } = new();

    [ObservableProperty] private string busca = string.Empty;
    [ObservableProperty] private Tarefa? selecionada;

    public TarefasViewModel(DatabaseService db)
    {
        _db = db;
        Filtros.Add(new Chip { Texto = "Todas", Valor = 0, Selecionado = true });
        Filtros.Add(new Chip { Texto = "Pendentes", Valor = 1 });
        Filtros.Add(new Chip { Texto = "Concluídas", Valor = 2 });
    }

    partial void OnBuscaChanged(string value) => Filtrar();

    partial void OnSelecionadaChanged(Tarefa? value)
    {
        if (value is null) return;
        var id = value.Id;
        Selecionada = null;
        _ = Shell.Current.GoToAsync($"tarefa-form?id={id}");
    }

    public async Task CarregarAsync()
    {
        _todas = await _db.ListarTarefasAsync();
        Filtrar();
    }

    private void Filtrar()
    {
        var termo = Busca?.Trim() ?? string.Empty;
        IEnumerable<Tarefa> lista = _todas;

        lista = _filtro switch
        {
            1 => lista.Where(t => !t.Concluida),
            2 => lista.Where(t => t.Concluida),
            _ => lista
        };

        if (termo.Length > 0)
            lista = lista.Where(t => t.Titulo.Contains(termo, StringComparison.OrdinalIgnoreCase)
                                  || t.Descricao.Contains(termo, StringComparison.OrdinalIgnoreCase));

        // Pendentes primeiro (por vencimento), concluídas no fim
        lista = lista.OrderBy(t => t.Concluida).ThenBy(t => t.Vencimento);

        Tarefas.Clear();
        foreach (var t in lista) Tarefas.Add(t);
    }

    [RelayCommand]
    private void SelecionarFiltro(Chip chip)
    {
        foreach (var f in Filtros) f.Selecionado = f == chip;
        _filtro = chip.Valor;
        Filtrar();
    }

    [RelayCommand]
    private async Task NovaAsync() => await Shell.Current.GoToAsync("tarefa-form");

    [RelayCommand]
    private async Task AlternarAsync(Tarefa tarefa)
    {
        if (tarefa is null) return;
        tarefa.Concluida = !tarefa.Concluida;
        await _db.SalvarTarefaAsync(tarefa);
        await CarregarAsync();
    }

    [RelayCommand]
    private async Task MenuAsync(Tarefa tarefa)
    {
        if (tarefa is null) return;
        var acao = await Shell.Current.DisplayActionSheet(tarefa.Titulo, "Cancelar", null, "Editar", "Excluir");
        if (acao == "Editar")
            await Shell.Current.GoToAsync($"tarefa-form?id={tarefa.Id}");
        else if (acao == "Excluir")
        {
            var ok = await Shell.Current.DisplayAlert("Excluir tarefa", $"Excluir \"{tarefa.Titulo}\"?", "Excluir", "Cancelar");
            if (!ok) return;
            await _db.ApagarTarefaAsync(tarefa);
            await CarregarAsync();
        }
    }
}
