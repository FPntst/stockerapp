using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using EstoqueApp.Services;

namespace EstoqueApp.ViewModels;

public partial class CadastroViewModel : ObservableObject
{
    private readonly AuthService _auth;

    [ObservableProperty] private string nome = string.Empty;
    [ObservableProperty] private string email = string.Empty;
    [ObservableProperty] private string senha = string.Empty;
    [ObservableProperty] private bool ocupado;

    public CadastroViewModel(AuthService auth) => _auth = auth;

    [RelayCommand]
    private async Task CriarAsync()
    {
        if (string.IsNullOrWhiteSpace(Nome) || !Email.Contains('@') || Senha.Length < 6)
        {
            await Shell.Current.DisplayAlert("Atenção",
                "Informe seu nome, um e-mail válido e uma senha com pelo menos 6 caracteres.", "OK");
            return;
        }

        Ocupado = true;
        var erro = await _auth.RegistrarAsync(Nome, Email, Senha);
        Ocupado = false;

        if (erro is not null)
        {
            await Shell.Current.DisplayAlert("Atenção", erro, "OK");
            return;
        }

        await Shell.Current.GoToAsync("//inicio");
    }

    [RelayCommand]
    private async Task VoltarAsync() => await Shell.Current.GoToAsync("..");
}
