using System.Collections.ObjectModel;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using EstoqueApp.Models;
using EstoqueApp.Services;

namespace EstoqueApp.ViewModels;

public partial class InicioViewModel : ObservableObject
{
    private readonly DatabaseService _db;
    private readonly AuthService _auth;
    private List<Produto> _todos = new();

    public ObservableCollection<Produto> Produtos { get; } = new();

    [ObservableProperty] private string saudacao = "Olá!";
    [ObservableProperty] private int totalItens;
    [ObservableProperty] private int emEstoque;
    [ObservableProperty] private int baixos;
    [ObservableProperty] private string busca = string.Empty;
    [ObservableProperty] private Produto? selecionado;

    public InicioViewModel(DatabaseService db, AuthService auth)
    {
        _db = db;
        _auth = auth;
    }

    partial void OnBuscaChanged(string value) => Filtrar();

    partial void OnSelecionadoChanged(Produto? value)
    {
        if (value is null) return;
        var id = value.Id;
        Selecionado = null;
        _ = Shell.Current.GoToAsync($"produto-detalhe?id={id}");
    }

    public async Task CarregarAsync()
    {
        _todos = await _db.ListarProdutosAsync();

        var primeiro = _auth.Atual?.Nome.Split(' ', StringSplitOptions.RemoveEmptyEntries).FirstOrDefault();
        Saudacao = string.IsNullOrEmpty(primeiro) ? "Olá!" : $"Olá, {primeiro}!";

        TotalItens = _todos.Count;
        Baixos = _todos.Count(p => p.EstoqueBaixo);
        EmEstoque = TotalItens - Baixos;
        Filtrar();
    }

    private void Filtrar()
    {
        var termo = Busca?.Trim() ?? string.Empty;
        IEnumerable<Produto> lista = _todos;

        if (termo.Length > 0)
            lista = lista.Where(p => p.Nome.Contains(termo, StringComparison.OrdinalIgnoreCase)
                                  || p.Categoria.Contains(termo, StringComparison.OrdinalIgnoreCase)
                                  || p.IdTexto.Contains(termo, StringComparison.OrdinalIgnoreCase));
        else
            lista = lista.Take(5);

        Produtos.Clear();
        foreach (var p in lista) Produtos.Add(p);
    }

    [RelayCommand]
    private async Task VerTodosAsync() => await Shell.Current.GoToAsync("//produtos");

    [RelayCommand]
    private async Task AlertasAsync()
    {
        var msg = Baixos == 0
            ? "Tudo certo! Nenhum item com estoque baixo."
            : $"{Baixos} item(ns) com estoque baixo (menos de {Produto.LimiteBaixo} unidades).";
        await Shell.Current.DisplayAlert("Alertas", msg, "OK");
    }
}
