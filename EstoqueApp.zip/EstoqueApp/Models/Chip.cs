using CommunityToolkit.Mvvm.ComponentModel;

namespace EstoqueApp.Models;

// Botão de filtro / seleção (categorias, status das tarefas, prioridade)
public partial class Chip : ObservableObject
{
    public string Texto { get; set; } = string.Empty;
    public int Valor { get; set; }
    public Color Cor { get; set; } = Color.FromArgb("#3B82F6");

    [ObservableProperty]
    [NotifyPropertyChangedFor(nameof(CorFundo))]
    private bool selecionado;

    public Brush CorBrush => new SolidColorBrush(Cor);
    public Color CorFundo => Selecionado ? Cor.WithAlpha(0.28f) : Colors.Transparent;
}
