using SQLite;

namespace EstoqueApp.Models;

public class Usuario
{
    [PrimaryKey, AutoIncrement]
    public int Id { get; set; }

    public string Nome { get; set; } = string.Empty;

    [Indexed(Unique = true)]
    public string Email { get; set; } = string.Empty;

    public string SenhaHash { get; set; } = string.Empty;
    public string Salt { get; set; } = string.Empty;
}
