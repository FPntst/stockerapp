using SQLite;

namespace EstoqueApp.Models;

public class Tarefa
{
    [PrimaryKey, AutoIncrement]
    public int Id { get; set; }

    public string Titulo { get; set; } = string.Empty;
    public string Descricao { get; set; } = string.Empty;

    // 0 = Baixa, 1 = Média, 2 = Alta
    public int Prioridade { get; set; } = 1;
    public DateTime Vencimento { get; set; } = DateTime.Today;
    public bool Concluida { get; set; }

    [Ignore] public string PrioridadeNome => Prioridade switch { 0 => "Baixa", 1 => "Média", _ => "Alta" };
    [Ignore] public string PrioridadeTexto => $"Prioridade: {PrioridadeNome}";
    [Ignore] public string DataTexto => Vencimento.ToString("dd/MM/yyyy");

    [Ignore] public Color CorPrioridade => Prioridade switch
    {
        0 => Color.FromArgb("#3B82F6"),
        1 => Color.FromArgb("#F59E0B"),
        _ => Color.FromArgb("#F43F5E")
    };

    [Ignore] public Brush CorPrioridadeBrush => new SolidColorBrush(CorPrioridade);
}
