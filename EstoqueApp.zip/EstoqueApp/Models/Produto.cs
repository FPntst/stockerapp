using System.Globalization;
using SQLite;

namespace EstoqueApp.Models;

public class Produto
{
    public const int LimiteBaixo = 3;
    public static readonly string[] CategoriasPadrao = { "Eletrônicos", "Acessórios", "Outros" };
    private static readonly CultureInfo Br = new("pt-BR");

    // ID próprio e automático de cada produto (autoincremento no SQLite)
    [PrimaryKey, AutoIncrement]
    public int Id { get; set; }

    public string Nome { get; set; } = string.Empty;
    public string Categoria { get; set; } = string.Empty;
    public int Quantidade { get; set; }
    public double Preco { get; set; }
    public string Descricao { get; set; } = string.Empty;
    public DateTime CriadoEm { get; set; } = DateTime.Now;

    [Ignore] public string IdTexto => $"ID: {Id:D3}";
    [Ignore] public string PrecoTexto => Preco.ToString("C", Br);
    [Ignore] public string QuantidadeTexto => $"{Quantidade} un.";
    [Ignore] public string QuantidadeLonga => Quantidade == 1 ? "1 unidade" : $"{Quantidade} unidades";
    [Ignore] public bool EstoqueBaixo => Quantidade < LimiteBaixo;

    [Ignore] public string Icone => Categoria switch
    {
        "Eletrônicos" => "💻",
        "Acessórios" => "🖱️",
        _ => "📦"
    };

    [Ignore] public string StatusTexto => Quantidade == 0 ? "Esgotado" : EstoqueBaixo ? "Estoque baixo" : "Em estoque";

    [Ignore] public Color StatusCor => Quantidade == 0 ? Color.FromArgb("#F43F5E")
        : EstoqueBaixo ? Color.FromArgb("#F59E0B")
        : Color.FromArgb("#22C55E");

    [Ignore] public Color StatusCorFundo => StatusCor.WithAlpha(0.2f);
}
