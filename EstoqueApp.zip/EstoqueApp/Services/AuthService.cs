using System.Security.Cryptography;
using EstoqueApp.Models;

namespace EstoqueApp.Services;

// Conta local no aparelho: senha guardada com hash PBKDF2 + salt (nunca em texto puro)
public class AuthService
{
    private readonly DatabaseService _db;

    public Usuario? Atual { get; private set; }

    public AuthService(DatabaseService db) => _db = db;

    public async Task<bool> RestaurarSessaoAsync()
    {
        var id = Preferences.Get("uid", 0);
        if (id == 0) return false;
        Atual = await _db.ObterUsuarioAsync(id);
        return Atual is not null;
    }

    // Retorna a mensagem de erro, ou null quando deu certo
    public async Task<string?> RegistrarAsync(string nome, string email, string senha)
    {
        email = email.Trim().ToLowerInvariant();
        if (await _db.ObterUsuarioPorEmailAsync(email) is not null)
            return "Já existe uma conta com este e-mail.";

        var salt = RandomNumberGenerator.GetBytes(16);
        var usuario = new Usuario
        {
            Nome = nome.Trim(),
            Email = email,
            Salt = Convert.ToBase64String(salt),
            SenhaHash = Hash(senha, salt)
        };
        await _db.InserirUsuarioAsync(usuario);
        Iniciar(usuario);
        return null;
    }

    public async Task<bool> EntrarAsync(string email, string senha)
    {
        var usuario = await _db.ObterUsuarioPorEmailAsync(email.Trim().ToLowerInvariant());
        if (usuario is null) return false;

        var calculado = Convert.FromBase64String(Hash(senha, Convert.FromBase64String(usuario.Salt)));
        var guardado = Convert.FromBase64String(usuario.SenhaHash);
        if (!CryptographicOperations.FixedTimeEquals(calculado, guardado)) return false;

        Iniciar(usuario);
        return true;
    }

    public void Sair()
    {
        Atual = null;
        Preferences.Remove("uid");
    }

    private void Iniciar(Usuario usuario)
    {
        Atual = usuario;
        Preferences.Set("uid", usuario.Id);
    }

    private static string Hash(string senha, byte[] salt)
        => Convert.ToBase64String(Rfc2898DeriveBytes.Pbkdf2(senha, salt, 100_000, HashAlgorithmName.SHA256, 32));
}
