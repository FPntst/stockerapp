using EstoqueApp.Models;
using SQLite;

namespace EstoqueApp.Services;

public class DatabaseService
{
    private SQLiteAsyncConnection? _db;
    private readonly SemaphoreSlim _lock = new(1, 1);

    private async Task<SQLiteAsyncConnection> ConnAsync()
    {
        if (_db is not null) return _db;

        await _lock.WaitAsync();
        try
        {
            if (_db is null)
            {
                var caminho = Path.Combine(FileSystem.AppDataDirectory, "stockflow.db3");
                var conn = new SQLiteAsyncConnection(caminho,
                    SQLiteOpenFlags.ReadWrite | SQLiteOpenFlags.Create | SQLiteOpenFlags.SharedCache);
                await conn.CreateTableAsync<Produto>();
                await conn.CreateTableAsync<Tarefa>();
                await conn.CreateTableAsync<Usuario>();
                _db = conn;
            }
        }
        finally { _lock.Release(); }

        return _db!;
    }

    // ---------- Produtos ----------
    public async Task<List<Produto>> ListarProdutosAsync()
        => await (await ConnAsync()).Table<Produto>().OrderBy(p => p.Id).ToListAsync();

    public async Task<Produto?> ObterProdutoAsync(int id)
        => await (await ConnAsync()).FindAsync<Produto>(id);

    // Id == 0 gera um novo ID automático; senão atualiza
    public async Task SalvarProdutoAsync(Produto p)
    {
        var c = await ConnAsync();
        if (p.Id == 0) await c.InsertAsync(p);
        else await c.UpdateAsync(p);
    }

    public async Task ApagarProdutoAsync(Produto p)
        => await (await ConnAsync()).DeleteAsync(p);

    // ---------- Tarefas ----------
    public async Task<List<Tarefa>> ListarTarefasAsync()
        => await (await ConnAsync()).Table<Tarefa>().ToListAsync();

    public async Task<Tarefa?> ObterTarefaAsync(int id)
        => await (await ConnAsync()).FindAsync<Tarefa>(id);

    public async Task SalvarTarefaAsync(Tarefa t)
    {
        var c = await ConnAsync();
        if (t.Id == 0) await c.InsertAsync(t);
        else await c.UpdateAsync(t);
    }

    public async Task ApagarTarefaAsync(Tarefa t)
        => await (await ConnAsync()).DeleteAsync(t);

    // ---------- Usuários ----------
    public async Task<Usuario?> ObterUsuarioAsync(int id)
        => await (await ConnAsync()).FindAsync<Usuario>(id);

    public async Task<Usuario?> ObterUsuarioPorEmailAsync(string email)
        => await (await ConnAsync()).Table<Usuario>().Where(u => u.Email == email).FirstOrDefaultAsync();

    public async Task InserirUsuarioAsync(Usuario u)
        => await (await ConnAsync()).InsertAsync(u);
}
